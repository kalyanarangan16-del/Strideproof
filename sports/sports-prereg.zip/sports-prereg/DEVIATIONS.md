# Deviations from preregistration
None recorded.
