Put exploratory notebooks here. Confirmatory analysis runs only through src/sportsprereg (make run).
