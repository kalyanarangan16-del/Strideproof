# Preregistered, Reproducible Analysis: Training Volume vs 10K Improvement

**Question:** Do club runners with higher weekly training volume improve their 10K time more over a 12-week block than low-volume runners?

## Structure
- `PREREGISTRATION.md`: PICO, hypotheses, exclusions, transformations, tests, effect sizes, robustness (locked)
- `requirements.lock`: exact environment (Python 3.12.3)
- `data/raw | interim | processed`: raw data is never edited
- `src/sportsprereg/`: config, synthetic generator, pipeline, report
- `contracts/output_contract.json`: expected output contract
- `tests/`: data-blind synthetic pipeline test + fixture
- `notebooks/`, `reports/`: exploration and outputs

## Use
```
pip install -r requirements.lock
make test     # data-blind check on synthetic fixtures (planted effect + null)
# place real data at data/raw/runners.csv with columns:
# athlete_id, age, level, weekly_km, baseline_10k_sec, followup_10k_sec, weeks_observed
make run
```
No real data has been analysed.
