"""Data-blind pipeline check on synthetic fixtures (run: python -m unittest discover -s tests -v)."""
import json, sys, unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from sportsprereg.synth import make_synthetic
from sportsprereg.pipeline import run, clean

C = json.loads((ROOT / "contracts" / "output_contract.json").read_text())
NB = 1000  # fewer resamples for test speed


class TestPipeline(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = make_synthetic(seed=1, true_slope=0.8)
        cls.d, cls.log, cls.prim, cls.rob = run(cls.raw, NB)
        cls.null = run(make_synthetic(seed=2, true_slope=0.0), NB)

    def test_exclusion_log_contract(self):
        self.assertEqual(list(self.log.columns), C["exclusion_log_columns"])
        self.assertEqual(list(self.log["rule"]), C["exclusion_rules_in_order"])

    def test_exclusions_remove_planted_dirt(self):
        removed = dict(zip(self.log["rule"], self.log["removed"]))
        self.assertGreater(removed["1 missing values"], 0)
        self.assertGreater(removed["2 implausible values"], 0)
        self.assertGreaterEqual(removed["3 duplicates"], 10)
        self.assertGreater(removed["4 window outside 10-14 wks"], 0)
        self.assertGreater(removed["5 age outside 18-65"], 0)

    def test_analytic_contract(self):
        self.assertEqual(list(self.d.columns), C["analytic_columns"])
        self.assertTrue(set(self.d.tier) <= set(C["tier_values"]))
        self.assertFalse(self.d["improvement_pct"].isna().any())
        self.assertFalse(self.d.duplicated("athlete_id").any())

    def test_result_keys(self):
        self.assertEqual(sorted(self.prim), sorted(C["primary_keys"]))
        self.assertEqual(sorted(self.rob), sorted(C["robustness_keys"]))

    def test_ci_contains_estimate(self):
        lo, hi = self.prim["median_diff_ci"]
        self.assertLessEqual(lo, self.prim["median_diff"] + 1e-9)
        self.assertGreaterEqual(hi, self.prim["median_diff"] - 1e-9)

    def test_planted_effect_recovered(self):
        self.assertTrue(self.prim["supports_H1"])
        self.assertGreater(self.prim["median_diff"], 0)
        self.assertGreater(self.prim["cliffs_delta"], 0)

    def test_null_not_supported(self):
        self.assertFalse(self.null[2]["supports_H1"])

    def test_determinism(self):
        self.assertEqual(run(self.raw, NB)[2], self.prim)

    def test_clean_is_input_order_invariant(self):
        a, _ = clean(self.raw)
        b, _ = clean(self.raw.sample(frac=1, random_state=9))
        self.assertEqual(list(a.athlete_id), list(b.athlete_id))


if __name__ == "__main__":
    unittest.main()
