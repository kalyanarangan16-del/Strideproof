import numpy as np
import pandas as pd
from scipy import stats
from .config import *


def clean(df):
    """Apply preregistered exclusion rules in order; return (analytic df, exclusion log)."""
    log = [{"rule": "start", "removed": 0, "remaining": len(df)}]

    def step(name, d, mask):
        out = d[mask].copy()
        log.append({"rule": name, "removed": len(d) - len(out), "remaining": len(out)})
        return out

    d = step("1 missing values", df,
             df[["baseline_10k_sec", "followup_10k_sec", "weekly_km"]].notna().all(axis=1))
    ok_t = lambda s: s.between(TIME_MIN, TIME_MAX)
    d = step("2 implausible values", d,
             ok_t(d["baseline_10k_sec"]) & ok_t(d["followup_10k_sec"])
             & (d["weekly_km"] > 0) & (d["weekly_km"] <= KM_MAX))
    d = d.sort_values(["weeks_observed", "athlete_id"], ascending=[False, True])
    d = step("3 duplicates", d, ~d.duplicated("athlete_id"))
    d = step("4 window outside 10-14 wks", d, d["weeks_observed"].between(WEEKS_MIN, WEEKS_MAX))
    d = step("5 age outside 18-65", d, d["age"].between(AGE_MIN, AGE_MAX))
    return d.sort_values("athlete_id").reset_index(drop=True), pd.DataFrame(log)


def transform(d):
    d = d.copy()
    d["improvement_pct"] = (d["baseline_10k_sec"] - d["followup_10k_sec"]) / d["baseline_10k_sec"] * 100
    q1, q2 = d["weekly_km"].quantile([1 / 3, 2 / 3])
    d["tier"] = np.where(d["weekly_km"] <= q1, "low", np.where(d["weekly_km"] > q2, "high", "mid"))
    return d


def cliffs_delta(a, b):
    a, b = np.asarray(a), np.asarray(b)
    u = stats.mannwhitneyu(a, b, alternative="two-sided").statistic
    return 2 * u / (len(a) * len(b)) - 1


def boot_ci(a, b, fn, n=N_BOOT, seed=SEED):
    rng = np.random.default_rng(seed)
    a, b = np.asarray(a), np.asarray(b)
    vals = np.empty(n)
    for i in range(n):
        vals[i] = fn(rng.choice(a, len(a)), rng.choice(b, len(b)))
    return tuple(float(v) for v in np.percentile(vals, [2.5, 97.5]))


def compare(hi, lo, n_boot=N_BOOT):
    mw = stats.mannwhitneyu(hi, lo, alternative="greater")
    dmed = lambda x, y: float(np.median(x) - np.median(y))
    return {
        "n_high": len(hi), "n_low": len(lo),
        "mannwhitney_U": float(mw.statistic), "p_one_sided": float(mw.pvalue),
        "median_diff": dmed(hi, lo),
        "median_diff_ci": boot_ci(hi, lo, dmed, n_boot),
        "cliffs_delta": float(cliffs_delta(hi, lo)),
        "cliffs_delta_ci": boot_ci(hi, lo, cliffs_delta, n_boot),
    }


def primary(d, n_boot=N_BOOT):
    hi = d.loc[d.tier == "high", "improvement_pct"].values
    lo = d.loc[d.tier == "low", "improvement_pct"].values
    res = compare(hi, lo, n_boot)
    res["supports_H1"] = bool(res["p_one_sided"] < ALPHA and res["median_diff"] > 0)
    return res


def robustness(d):
    out = {}
    y = d["improvement_pct"]
    hi, lo = y[d.tier == "high"], y[d.tier == "low"]
    out["welch_p_one_sided"] = float(stats.ttest_ind(hi, lo, equal_var=False, alternative="greater").pvalue)
    q1, q3 = d["weekly_km"].quantile([.25, .75])
    out["quartile_median_diff"] = float(y[d.weekly_km > q3].median() - y[d.weekly_km <= q1].median())
    lo_w, hi_w = y.quantile([.01, .99])
    w = y.clip(lo_w, hi_w)
    out["winsorised_median_diff"] = float(w[d.tier == "high"].median() - w[d.tier == "low"].median())
    e = d[d.weekly_km <= d["weekly_km"].quantile(.99)]
    out["excl_top1pct_median_diff"] = float(e.loc[e.tier == "high", "improvement_pct"].median()
                                            - e.loc[e.tier == "low", "improvement_pct"].median())
    diffs, ws = [], []
    for g, s in d.groupby("level"):
        a, b = s.loc[s.tier == "high", "improvement_pct"], s.loc[s.tier == "low", "improvement_pct"]
        if len(a) >= 5 and len(b) >= 5:
            diffs.append(a.median() - b.median()); ws.append(len(s))
    out["within_level_weighted_median_diff"] = float(np.average(diffs, weights=ws))
    return out


def run(raw, n_boot=N_BOOT):
    d, log = clean(raw)
    d = transform(d)
    return d, log, primary(d, n_boot), robustness(d)
