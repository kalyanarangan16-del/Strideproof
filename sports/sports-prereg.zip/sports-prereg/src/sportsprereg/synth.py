"""Synthetic runner data with a KNOWN planted effect (for data-blind checks)."""
import numpy as np
import pandas as pd
from .config import LEVELS


def make_synthetic(n=1500, seed=1, true_slope=0.8, dirty=True):
    rng = np.random.default_rng(seed)
    km = np.clip(rng.normal(40, 14, n), 5, 120)
    z = (km - 40) / 14
    improvement = 2.0 + true_slope * z + rng.normal(0, 3.0, n)   # percent
    baseline = rng.normal(3000, 450, n).clip(1800, 6000)
    follow = baseline * (1 - improvement / 100)
    df = pd.DataFrame({
        "athlete_id": [f"A{i:05d}" for i in range(n)],
        "age": rng.integers(16, 71, n),
        "level": rng.choice(LEVELS, n),
        "weekly_km": km.round(1),
        "baseline_10k_sec": baseline.round(0),
        "followup_10k_sec": follow.round(0),
        "weeks_observed": rng.integers(8, 17, n),
    })
    if dirty:
        d = df.sample(frac=0.03, random_state=seed).index
        df.loc[d, "baseline_10k_sec"] = np.nan
        d2 = df.sample(frac=0.02, random_state=seed + 1).index
        df.loc[d2, "followup_10k_sec"] = -1
        df = pd.concat([df, df.sample(30, random_state=seed + 2)], ignore_index=True)
    return df
