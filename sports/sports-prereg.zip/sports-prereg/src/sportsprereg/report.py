import json, sys
from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from .pipeline import run


def main(raw_path="data/raw/runners.csv"):
    raw = pd.read_csv(raw_path)
    d, log, prim, rob = run(raw)
    Path("data/processed").mkdir(parents=True, exist_ok=True)
    Path("reports/figures").mkdir(parents=True, exist_ok=True)
    d.to_csv("data/processed/analytic.csv", index=False)
    log.to_csv("reports/exclusion_log.csv", index=False)
    Path("reports/results.json").write_text(json.dumps({"primary": prim, "robustness": rob}, indent=2))
    d[d.tier != "mid"].boxplot(column="improvement_pct", by="tier", grid=False)
    plt.suptitle(""); plt.title("10K improvement by training-volume tier"); plt.ylabel("improvement (%)")
    plt.savefig("reports/figures/improvement_by_tier.png", dpi=150, bbox_inches="tight")
    print(json.dumps(prim, indent=2))


if __name__ == "__main__":
    main(*sys.argv[1:])
